package test.com.model;

public interface RoomUserDAO {
	public int update (RoomVO vo);
}
