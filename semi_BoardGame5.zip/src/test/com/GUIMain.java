package test.com;

public class GUIMain {

	public static void main(String[] args) {
		new Home();

		
//		new RoomSelectAllPage();
//		new RoomSelectAllPage(2018);
		
//		new GameSelectAllPage();
//		new GameSelectAllPage(2018);
		
//		new LoginPage();
		
//		new EventPage();
	}

}
